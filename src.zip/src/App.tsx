import Apple from "./components/courseCategory/Apple";
import Autodesk from "./components/courseCategory/Autodesk";
import Ccs from "./components/courseCategory/Ccs";
import Cisco from "./components/courseCategory/Cisco";
import Ic3 from "./components/courseCategory/Ic3";
import Intuit from "./components/courseCategory/Intuit";
import ItSpecialist from "./components/courseCategory/ItSpecialist";
import Mcf from "./components/courseCategory/Mcf";
import Mos from "./components/courseCategory/Mos";
import Unity from "./components/courseCategory/Unity";
import CourseCategory from "./pages/CourseCategory";
import Homepage from "./pages/Homepage";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import AdobeAfterEffects from "./pages/Productpage/AdobeAfterEffects";
import CoursePage from "./pages/CoursePage";
import AdobePhotoshop from "./pages/Productpage/AdobePhotoshop";
import AdobeAbrocat from "./pages/Productpage/AdobeAbrocat";
import AdobePremierPro from "./pages/Productpage/AdobePremierPro";
import AdobeAnimate from "./pages/Productpage/AdobeAnimate";
import AdobeExpress from "./pages/Productpage/AdobeExpress";
import AdobeIndesign from "./pages/Productpage/AdobeIndesign";
import AdobeIllustrator from "./pages/Productpage/AdobeIllustrator";
import AdobeDreamweaver from "./pages/Productpage/AdobeDreamweaver";
import CartPage from "./pages/CartPage";
import Navbar from "./components/navbar/Navbar";
import AuthCard from "./components/auth/AuthCard";
import { useAuth } from "./components/auth/AuthContext";
import StateCityCard from "./components/cart/StateCityCard";
import Dashboard from "./dashboard/Dashboard";
import Ibm from "./components/courseCategory/Ibm";
import PartnerWithUs from "./pages/PartnerWithUs";
import AboutUs from "./pages/AboutUs";
import ContactUs from "./pages/ContactUs";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsAndConditions from "./pages/TermsAndContidions";
import RefundPolicy from "./pages/RefundPolicy";
import SearchPage from "./pages/SearchPage";
import PaymentVerification from "./pages/PaymentVerification";
import EtrainIndiaHome from "./pages/EtrainIndiaHome";

const App = () => {
  const { isAuthOpen } = useAuth();
  return (
    <div>
      <Router>
          <Navbar />

        <Routes>
          <Route path="/" element={<Homepage />} />
          <Route
            path="/adobe"
            element={<CourseCategory />}
          />
          <Route path="/apple" element={<Apple />} />
          <Route path="/autodesk" element={<Autodesk />} />
          <Route path="/cisco" element={<Cisco />} />
          <Route path="/criticalcareerskills" element={<Ccs />} />
          <Route path="/ic3" element={<Ic3 />} />
          <Route path="/itspecialist" element={<ItSpecialist />} />
          <Route path="/intuit" element={<Intuit />} />
          <Route path="/ibm" element={<Ibm />} />
          <Route path="/mcf" element={<Mcf />} />
          <Route path="/mos" element={<Mos />} />
          <Route path="/unity" element={<Unity />} />
          <Route path="/adobe/aftereffects" element={<AdobeAfterEffects />} />
          <Route path="/adobe/photoshop" element={<AdobePhotoshop />} />
          <Route path="/:courseId" element={<AdobeAbrocat/>} />
          <Route path="/adobe/premierpro" element={<AdobePremierPro />} />
          <Route path="/adobe/animate" element={<AdobeAnimate />} />
          <Route path="/adobe/express" element={<AdobeExpress />} />
          <Route path="/adobe/indesign" element={<AdobeIndesign />} />
          <Route path="/adobe/illustrator" element={<AdobeIllustrator />} />
          <Route path="/adobe/dreamweaver" element={<AdobeDreamweaver />} />
          <Route path="/course" element={<CoursePage />} />
          <Route path="/partner" element={<div>Contact Page</div>} />
          <Route path="/about" element={<div>About Page</div>} />
          <Route path="/contact" element={<div>Contact Page</div>} />
          <Route path="/login" element={<div>Contact Page</div>} />
          <Route path="/cart" element={<CartPage/>} />
          <Route path="/state" element={<StateCityCard />} />
          <Route path="/dashboard" element={<Dashboard/>} />
          <Route path="/partnerwithus" element={<PartnerWithUs/>} />
          <Route path="/aboutus" element={<AboutUs/>} />
          <Route path="/contactus" element={<ContactUs/>} />
          <Route path="/privacypolicy" element={<PrivacyPolicy/>} />
          <Route path="/termsandconditions" element={<TermsAndConditions/>} />
          <Route path="/refundpolicy" element={<RefundPolicy/>} />
          <Route path="/search" element={<SearchPage/>} />
          <Route path="/paymentVerification" element={<PaymentVerification/>} />
          <Route path="/etrainindia" element={<EtrainIndiaHome />} />
          <Route path="*" element={<div>404 Not Found</div>} />
          {/* Add more routes as needed */}
        </Routes>
        {isAuthOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <AuthCard />
        </div>
      )}
      </Router>
    </div>
  );
};

export default App;
