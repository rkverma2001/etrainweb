const VideoSection = () => {
  return (
    <div className="flex flex-col md:flex-row gap-8 md:gap-12 items-center">
      {/* Left Content Section */}
      <div className="w-full md:w-1/2 bg-white overflow-y-auto">
        <img
          src="/CoursesCategories/AdobeBadges/AdobeCategoryLogo.svg"
          className="mb-5 h-16"
          alt="Adobe Category Logo"
        />
        <div className="mb-6 text-gray-700 text-justify leading-relaxed">
          <span>
            Adobe Certified Professional is the industry-recognized
            certification that demonstrates mastery of Adobe Creative Cloud
            software and must-have knowledge for digital media careers. Each
            exam is integrated with an Adobe application and designed by
            experts, allowing for an authentic assessment of job-ready skills.
          </span>
          <div className="mt-[15px]">
            EtrainIndia provides a full pathway solution that students can use
            to prepare for the Adobe Certified Professional certification. From
            tailored learning materials and practice tests to Adobe endorsed
            certification exams, EtrainIndia provides assistance every step of
            the way.
          </div>
        </div>
      </div>

      {/* Right Video Section */}
      <div className="w-full md:w-1/2 overflow-hidden">
        <video
          className="w-full h-64 md:h-84 border-2 rounded-2xl object-cover"
          autoPlay
          loop
          muted
          playsInline
          src="https://etrain.blr1.cdn.digitaloceanspaces.com/videos/adobe.mp4"
        />
      </div>
    </div>
  );
};

export default VideoSection;
