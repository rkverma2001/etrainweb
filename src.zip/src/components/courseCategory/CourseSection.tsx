import { useState } from "react";
import CourseCard from "./CourseCard";

interface Course {
  title: string;
  description: string;
  image: string;
  duration: string;
  slug?: string; // slug is optional for practice-tests and self-paced-course
}

const CourseSection = () => {
  const [selected, setSelected] = useState("exam-vouchers");

  const options = [
    { label: "Best Value Bundle", value: "bundle" },
    { label: "Exam Vouchers", value: "exam-vouchers" },
    { label: "Practice Tests", value: "practice-tests" },
    { label: "E-Learning Course", value: "self-paced-course" },
  ];

  const courseData: Record<string, Course[]> = {
   "bundle": [
    {
      title: "Adobe Certified Professional",
      description: "Adobe After Effects Exam Voucher",
      image: "AdobeProductImages/adobePIae.svg",
      duration: "2,199",
      slug: "/ADOBE-AFTER-101"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Photoshop Exam Voucher",
      image: "AdobeProductImages/adobePIps.svg",
      duration: "2,199",
      slug: "/ADOBE-PHOTO-102"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Acrobat Pro Exam Voucher",
      image: "AdobeProductImages/adobePIacro.svg",
      duration: "2,199",
      slug: "/ADOBE-ACRO-103"
    },
    
    {
      title: "Adobe Certified Professional",
      description: "Adobe Premier Pro Exam Voucher",
      image: "AdobeProductImages/adobePIpr.svg",
      duration: "2,199",
      slug: "/ADOBE-PREMIER-104"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Animate Exam Voucher",
      image: "AdobeProductImages/adobePIan.svg",
      duration: "2,199",
      slug: "/ADOBE-ANIMATE-105"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Express Exam Voucher",
      image: "AdobeProductImages/adobePIexp.svg",
      duration: "2,199",
      slug: "/ADOBE-EXPRESS-106"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe InDesign Exam Voucher",
      image: "AdobeProductImages/adobePIid.svg",
      duration: "2,199",
      slug: "/ADOBE-INDESIGN-107"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Illustrator Exam Voucher",
      image: "AdobeProductImages/adobePIai.svg",
      duration: "2,199",
      slug: "/ADOBE-ILLUSTRATOR-108"
    },
    {
      title: "Adobe Certified Professional",
      description:
        "Adobe Dreamweaver Exam Voucher",
      image: "AdobeProductImages/adobePIdw.svg",
      duration: "2,199",
      slug: "/ADOBE-DREAMWEAVER-109"
    },
    
  ],
    "exam-vouchers": [
    {
      title: "Adobe Certified Professional",
      description: "Adobe After Effects Exam Voucher",
      image: "AdobeProductImages/adobePIae.svg",
      duration: "2,199",
      slug: "/ADOBE-AFTER-101"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Photoshop Exam Voucher",
      image: "AdobeProductImages/adobePIps.svg",
      duration: "2,199",
      slug: "/ADOBE-PHOTO-102"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Acrobat Pro Exam Voucher",
      image: "AdobeProductImages/adobePIacro.svg",
      duration: "2,199",
      slug: "/ADOBE-ACRO-103"
    },
    
    {
      title: "Adobe Certified Professional",
      description: "Adobe Premier Pro Exam Voucher",
      image: "AdobeProductImages/adobePIpr.svg",
      duration: "2,199",
      slug: "/ADOBE-PREMIER-104"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Animate Exam Voucher",
      image: "AdobeProductImages/adobePIan.svg",
      duration: "2,199",
      slug: "/ADOBE-ANIMATE-105"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Express Exam Voucher",
      image: "AdobeProductImages/adobePIexp.svg",
      duration: "2,199",
      slug: "/adobe-express-106"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe InDesign Exam Voucher",
      image: "AdobeProductImages/adobePIid.svg",
      duration: "2,199",
      slug: "/adobe-indesign-107"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Illustrator Exam Voucher",
      image: "AdobeProductImages/adobePIai.svg",
      duration: "2,199",
      slug: "/adobe-illustrator-108"
    },
    {
      title: "Adobe Certified Professional",
      description:
        "Adobe Dreamweaver Exam Voucher",
      image: "AdobeProductImages/adobePIdw.svg",
      duration: "2,199",
      slug: "/adobe-dreamweaver-109"
    },
    
  ],

   "practice-tests": [
    {
      title: "Adobe Certified Professional",
      description: "Adobe After Effects Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIae.svg",
      duration: "899",
      slug: "/adobe-after-101"
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Photoshop Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIps.svg",
      duration: "899",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Acrobat Pro Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIacro.svg",
      duration: "899",
    },
    
    {
      title: "Adobe Certified Professional",
      description: "Adobe Premier Pro Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIpr.svg",
      duration: "899",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Animate Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIan.svg",
      duration: "899",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Express Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIexp.svg",
      duration: "899",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe InDesign Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIid.svg",
      duration: "899",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Illustrator Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIai.svg",
      duration: "899",
    },
    {
      title: "Adobe Certified Professional",
      description:
        "Adobe Dreamweaver Practice Test Voucher",
      image: "AdobeProductPracticeTestImages/adobePIdw.svg",
      duration: "899",
    },
    
  ],

  "self-paced-course": [
    {
      title: "Adobe Certified Professional",
      description: "Adobe After Effects Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIae.svg",
      duration: "1,149",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Photoshop Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIps.svg",
      duration: "1,149",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Acrobat Pro Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIacro.svg",
      duration: "1,149",
    },
    
    {
      title: "Adobe Certified Professional",
      description: "Adobe Premier Pro Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIpr.svg",
      duration: "1,149",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Animate Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIan.svg",
      duration: "1,149",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Express Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIexp.svg",
      duration: "1,149",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe InDesign Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIid.svg",
      duration: "1,149",
    },
    {
      title: "Adobe Certified Professional",
      description: "Adobe Illustrator Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIai.svg",
      duration: "1,149",
    },
    {
      title: "Adobe Certified Professional",
      description:
        "Adobe Dreamweaver Self-Paced Video-Based Learning Course Voucher",
      image: "AdobeLearningImages/adobePIdw.svg",
      duration: "1,149",
    },
    
  ],
};


  return (
    <div className="max-w-7xl mx-auto px-6 lg:px-10 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
      {/* Sidebar / Filters */}
      <aside className="lg:col-span-3">
        <div className="sticky top-28 bg-slate-50 rounded-lg p-6 border border-slate-100 shadow-sm"></div>
        <h4 className="text-lg font-semibold mb-4">Product Type</h4>
        <ul className="flex lg:flex-col justify-center gap-3 lg:space-y-3 text-gray-800 flex-wrap">
          {options.map((option) => (
            <li key={option.value} className="flex items-center">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={selected === option.value}
                  onChange={() => setSelected(option.value)}
                  className="form-checkbox text-blue-600"
                />
                <span className="text-sm lg:text-base mt-[-3px]">{option.label}</span>
              </label>
            </li>
          ))}
        </ul>
      </aside>

      {/* Main Content */}
      <main className="w-full lg:h-[530px] lg:w-4/5 p-4 sm:p-6 overflow-y-auto">
      
      {selected === "exam-vouchers" && (
  <>
    <h1 className="text-2xl text-center mb-2 font-semibold flex items-center justify-center gap-2 flex-wrap">
      <img
        src="/CoursesCategories/AdobeBadges/AdobeCategoryLogo.svg"
        alt="CertPREP Logo"
        className="h-14 object-contain inline-block"
      />
    </h1>
    <p className="text-center text-lg mb-10">
      Official digital exam codes to take your Adobe certification exam online with remote proctoring.
    </p>
  </>
)}
          {selected === "practice-tests" && (
  <>
    <h1 className="text-2xl text-center mb-2 font-semibold flex items-center justify-center gap-2 flex-wrap">
      <img
        src="/CoursesCategories/CertPREPLogo.png"
        alt="CertPREP Logo"
        className="h-16 object-contain inline-block"
      />
    </h1>
    <p className="text-center text-lg mb-10">
      Practice Tests are designed to simulate the real exam environment, helping you gain confidence and improve your performance.
    </p>
  </>
)}
{selected === "self-paced-course" && (
  <>
    <h1 className="text-2xl text-center mb-3 font-semibold flex items-center justify-center gap-2 flex-wrap">
      <img
        src="/CoursesCategories/LKlogo.png"
        alt="CertPREP Logo"
        className="h-12 object-contain inline-block"
      />
    </h1>
    <p className="text-center text-lg mb-10">
      These self-paced courses offer comprehensive training through engaging video content, quizzes, and assignments—delivered by certified industry experts.
    </p>
  </>
)}
        <div className="grid w-full grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-15">
          {courseData[selected].map((course, index) => (
  <CourseCard
    key={index}
    image={`/CoursesCategories/${course.image}`} // ensure `course.image` is just the filename
    title={course.title}
    price={course.duration}
    description={course.description}
    slug={course.slug || ""}
  />
))}
        </div>
      </main>
      </div>
    </div>
  );
};

export default CourseSection;
