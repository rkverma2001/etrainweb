import Footer from "@/components/footer/Footer";
import Navbar from "@/components/navbar/Navbar";
import { useState } from "react";
import CourseCard from "./CourseCard";
import { CheckCircle2 } from "lucide-react";

const Mos = () => {
  const logos = ["1.svg", "2.svg", "3.svg", "4.svg", "5.svg", "6.svg", "7.svg", "8.svg", "9.svg", "10.svg", "11.svg", "12.svg"];

  const [selected, setSelected] = useState("exam-vouchers");

  const options = [
    { label: "Exam Vouchers", value: "exam-vouchers" },
    { label: "Practice Tests", value: "practice-tests" },
    { label: "E-Learning Course", value: "self-paced-course" },
  ];

  const courseData: Record<
    string,
    { title: string; description: string; image: string; duration: string }[]
  > = {
    "exam-vouchers": [
      {
        title: "Microsoft Office Specialist",
        description: "Excel Expert Certification Exam Voucher",
        image: "/MosImage/1.svg",
        duration: "₹ 2,199",
      },
      {
        title: "Microsoft Office Specialist",
        description: "Word Expert Certification Exam Voucher",
        image: "/MosImage/2.svg",
        duration: "₹ 2,199",
      },
      {
        title: "Microsoft Office Specialist",
        description: "PowerPoint Associate Certification Exam Voucher",
        image: "/MosImage/3.svg",
        duration: "₹ 2,199",
      },
      {
        title: "Microsoft Office Specialist",
        description: "Excel Associate Certification Exam Voucher",
        image: "/MosImage/4.svg",
        duration: "₹ 2,199",
      },
      {
        title: "Microsoft Office Specialist",
        description: "Word Associate Certification Exam Voucher",
        image: "/MosImage/5.svg",
        duration: "₹ 2,199",
      },
    ],

    "practice-tests": [
      {
        title: "Microsoft Office Specialist",
        description: "Excel Expert Certification Practice Test Voucher",
        image: "/MosImage/6.svg",
        duration: "₹ 899",
      },
      {
        title: "Microsoft Office Specialist",
        description: "Word Expert Certification Practice Test Voucher",
        image: "/MosImage/7.svg",
        duration: "₹ 899",
      },
      {
        title: "Microsoft Office Specialist",
        description: "PowerPoint Associate Certification Practice Test Voucher",
        image: "/MosImage/8.svg",
        duration: "₹ 899",
      },
      {
        title: "Microsoft Office Specialist",
        description: "Excel Associate Certification Practice Test Voucher",
        image: "/MosImage/9.svg",
        duration: "₹ 899",
      },
      {
        title: "Microsoft Office Specialist",
        description: "Word Associate Certification Practice Test Voucher",
        image: "/MosImage/10.svg",
        duration: "₹ 899",
      },
    ],

    "self-paced-course": [
      {
        title: "Microsoft Office Specialist",
        description:
          "Excel Expert Certification Self-Paced Video Based Learning Course Voucher",
        image: "/MosImage/11.svg",
        duration: "₹ 1,150",
      },
      {
        title: "Microsoft Office Specialist",
        description:
          "Word Expert Certification Self-Paced Video Based Learning Course Voucher",
        image: "/MosImage/12.svg",
        duration: "₹ 1,150",
      },
      {
        title: "Microsoft Office Specialist",
        description:
          "PowerPoint Associate Certification Self-Paced Video Based Learning Course Voucher",
        image: "/MosImage/13.svg",
        duration: "₹ 1,150",
      },
      {
        title: "Microsoft Office Specialist",
        description:
          "Excel Associate Certification Self-Paced Video Based Learning Course Voucher",
        image: "/MosImage/14.svg",
        duration: "₹ 1,150",
      },
      {
        title: "Microsoft Office Specialist",
        description:
          "Word Associate Certification Self-Paced Video Based Learning Course Voucher",
        image: "/MosImage/15.svg",
        duration: "₹ 1,150",
      },
    ],
  };

  const features = [
    "Add them to your LinkedIn profile, resume, or CV to boost credibility.",
    "Earn globally recognized certifications from Microsoft Office Specialist.",
    "Receive official digital badges from Credly to showcase your skills online.",
    "Enhance your career prospects during interviews, internships, or performance evaluations.",
  ];

  return (
    <div className="relative overflow-hidden bg-white py-8">
      <Navbar onLoginClick={() => console.log("login clicked")} />

      <div className="mt-14">
        <div className="flex flex-col md:flex-row">
          {/* Left Content Section */}
          <div className="w-full md:w-1/2 p-6 md:p-10 bg-white overflow-y-auto">
            <img
              src="/logos/Microsoft.svg"
              className="mb-5 mt-[-34px] h-16"
              alt="Mos Logo"
            />
            <div className="mb-6 text-gray-700 text-justify leading-relaxed">
              <span>
                Microsoft Office Specialist (MOS) is an industry-recognized
                certification program that validates skills in Microsoft Office
                applications. MOS certification gives individuals the ability to
                achieve professional success in diverse professional
                environments, including business and finance, healthcare,
                computer science and IT, engineering, and more. It also empowers
                educators, employers, and the overall job industry.
              </span>
              <div className="mt-[15px]">
                EtrainIndia provides a full pathway solution that students can
                use to prepare for the Microsoft Office Specialist
                certifications. From tailored learning materials and practice
                tests to Microsoft Office Specialist
                endorsed certification exams, EtrainIndia provides assistance
                every step of the way.
              </div>
            </div>
          </div>

          {/* Right Video Section */}
          <div className="w-full md:w-1/2 overflow-hidden">
            <video
              className="w-full h-64 md:h-84 border-2 rounded-2xl object-cover"
              autoPlay
              loop
              muted
              playsInline
              src="/videos/mos.mp4"
            />
          </div>
        </div>
      </div>
      <div className="mt-[-20px]">
        <div className="w-48 animate-marquee whitespace-nowrap bg-white ">
          {logos.concat(logos).map((logo, index) => (
            <img
              key={index}
              src={`/CoursesCategories/MosBadges/${logo}`}
              alt={logo}
              className="h-28 mx-[38px] inline-block"
            />
          ))}
        </div>
      </div>

      <div className="flex mt-10 items-center justify-center">
        <div className="flex flex-col lg:flex-row w-full min-h-screen">
          {/* Sidebar / Filters */}
          <aside className="w-full lg:h-[530px] lg:w-1/5 bg-gray-100 p-4 border-b lg:border-b-0 lg:border-r">
            <h2 className="text-lg lg:text-xl font-semibold mb-3 text-center lg:text-left">
              Product Type
            </h2>
            <ul className="flex lg:flex-col justify-center gap-3 lg:space-y-3 text-gray-800 flex-wrap">
              {options.map((option) => (
                <li key={option.value} className="flex items-center">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selected === option.value}
                      onChange={() => setSelected(option.value)}
                      className="form-checkbox text-blue-600"
                    />
                    <span className="text-sm lg:text-base">{option.label}</span>
                  </label>
                </li>
              ))}
            </ul>
          </aside>

          {/* Main Content */}
          <main className="w-full lg:h-[530px] lg:w-4/5 p-4 sm:p-6 overflow-y-auto">
            {selected === "exam-vouchers" && (
              <>
                <h1 className="text-2xl text-center mb-2 font-semibold flex items-center justify-center gap-2 flex-wrap">
                  <img
                    src="/logos/Microsoft.svg"
                    alt="Microsoft Logo"
                    className="h-18 object-contain inline-block"
                  />
                </h1>
                <p className="text-center text-lg mb-10">
                  Official digital exam codes to take your Microsoft Office Specialist certification exam online with remote proctoring.
                </p>
              </>
            )}
            {selected === "practice-tests" && (
              <>
                <h1 className="text-2xl text-center mb-2 font-semibold flex items-center justify-center gap-2 flex-wrap">
                  <img
                    src="/CoursesCategories/CertPREPLogo.png"
                    alt="CertPREP Logo"
                    className="h-16 object-contain inline-block"
                  />
                </h1>
                <p className="text-center text-lg mb-10">
                  Practice Tests are designed to simulate the real exam
                  environment, helping you gain confidence and improve your
                  performance.
                </p>
              </>
            )}
            {selected === "self-paced-course" && (
              <>
                <h1 className="text-2xl text-center mb-3 font-semibold flex items-center justify-center gap-2 flex-wrap">
                  <img
                    src="/CoursesCategories/LKlogo.png"
                    alt="CertPREP Logo"
                    className="h-12 object-contain inline-block"
                  />
                </h1>
                <p className="text-center text-lg mb-10">
                  These self-paced courses offer comprehensive training through
                  engaging content, quizzes, and assignments—delivered by
                  certified industry experts.
                </p>
              </>
            )}
            <div className="grid w-full grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-15">
              {courseData[selected].map((course, index) => (
                <CourseCard
                  key={index}
                  image={`/CoursesCategories/${course.image}`} // ensure `course.image` is just the filename
                  title={course.title}
                  price={course.duration}
                  description={course.description}
                />
              ))}
            </div>
          </main>
        </div>
      </div>
      <div>
        <div className="flex flex-col md:flex-row w-full h-auto md:h-[500px]">
          {/* Left Section */}
          <div className="w-full md:w-1/2 flex items-center justify-center p-6 bg-white">
            <div className=" p-6 w-full max-w-lg h-fit">
              <h2 className="text-4xl ml-1 font-semibold text-gray-800 mb-12">
                Get Industry-Recognized Certifications & Digital Badge
              </h2>
              <ul className="space-y-4 text-gray-700 text-base">
                {features.map((item, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <div className="w-6 h-6  rounded-full flex items-center justify-center mt-1 shrink-0">
                      <CheckCircle2 className="text-green-600 w-4 h-4" />
                    </div>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right Section - Certificate Image */}
          <div className="w-full md:w-1/2 flex items-center justify-center p-6">
            <img
              src="\CoursesCategories\MosCertificate.jpg"
              alt="MCF Certificate"
              className="h-full w-[600px] object-contain max-h-[500px]  rounded-xl shadow-lg"
            />
          </div>
        </div>
      </div>
      <div className="mt-24 mb-[-40px]">
        <Footer />
      </div>
    </div>
  );
};

export default Mos;
