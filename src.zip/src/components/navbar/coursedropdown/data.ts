const courseData = [
  {
    categoryName: "Adobe",
    categorySlug: "/adobe",
    courses: [
      { name: "After Effects", slug: "/ADOBE-AFTER-101" },
      { name: "Photoshop", slug: "/ADOBE-PHOTO-102" },
      { name: "Acrobat", slug: "/ADOBE-ACRO-103" },
      { name: "Premier", slug: "/ADOBE-PREMIER-104" },
      { name: "Animate", slug: "/ADOBE-ANIMATE-105" },
      { name: "Express", slug: "/ADOBE-EXPRESS-106" },
      { name: "Indesign", slug: "/ADOBE-INDESIGN-107" },
      { name: "Illustrator", slug: "/ADOBE-ILLUSTRATOR-108" },
      { name: "Dreamweaver", slug: "/ADOBE-DREAMWEAVER-109" }
    ],
  },
  {
    categoryName: "Autodesk",
    categorySlug: "/autodesk",
    courses: [
      { name: "Autocad", slug: "/AUTODESK-AUTOCAD-101" },
      { name: "Inventor", slug: "/AUTODESK-INVENTOR-102" },
      { name: "Fusion", slug: "/AUTODESK-FUSION-103" },
      { name: "3ds Max", slug: "/AUTODESK-3DSMAX-104" },
      { name: "Maya", slug: "/AUTODESK-MAYA-105" },
      { name: "Revit", slug: "/AUTODESK-REVIT-106" }
    ],
  },
  {
    categoryName: "Apple",
    categorySlug: "/apple",
    courses: [
      { name: "Swift Certified User", slug: "/APPLE-SWIFT-CERTIFIED-101" },
      { name: "Swift Associate User", slug: "/APPLE-SWIFT-ASSOCIATE-102" }
    ],
  },
  {
    categoryName: "Cisco",
    categorySlug: "/cisco",
    courses: [
      { name: "CCST Cybersecurity", slug: "/CISCO-CYBERSECURITY-101" },
      { name: "CCST Networking", slug: "/CISCO-NETWORKING-102" },
      { name: "CCST IT Support", slug: "/CISCO-ITSUPPORT-103" },
    ],
  },
  {
    categoryName: "Critical Career Skills",
    categorySlug: "/criticalcareerskills",
    courses: [
      { name: "Generative AI Foundations", slug: "/ccs-genai-101" },
      { name: "Professional Communication", slug: "/ccs-profcom-102" }
    ],
  },
  {
    categoryName: "IC3 Digital Literacy",
    categorySlug: "/ic3",
    courses: [
      { name: "Global Standard 6 Level 1", slug: "/ic3-gs1-101" },
      { name: "Global Standard 6 Level 2", slug: "/ic3-gs2-102" },
      { name: "Global Standard 6 Level 3", slug: "/ic3-gs3-103" },
      { name: "Spark", slug: "/ic3-spark-104" },
      { name: "PHP", slug: "/ic3-php-105" }
    ],
  },
  {
    categoryName: "IT Specialist",
    categorySlug: "/itspecialist",
    courses: [
      { name: "Artificial Intelligence", slug: "/its-ai-101" },
      { name: "Cloud Computing", slug: "/its-cloudcomputing-102" },
      { name: "Computational Thinking", slug: "/its-computationalthinking-103" },
      { name: "Cybersecurity", slug: "/its-cybersecurity-104" },
      { name: "Data Analytics", slug: "/its-dataanalytics-105" },
      { name: "Databases", slug: "/its-databases-106" },
      { name: "Device Configuration and Management", slug: "/its-deviceconfig-107" },
      { name: "HTML and CSS", slug: "/its-htmlcss-108" },
      { name: "HTML 5 Application Development", slug: "/its-html5-109" },
      { name: "Java", slug: "/its-java-110" },
      { name: "JavaScript", slug: "/its-javascript-111" },
      { name: "Networking", slug: "/its-networking-112" },
      { name: "Network Security", slug: "/its-networksecurity-113" },
      { name: "Python", slug: "/its-python-114" },
      { name: "Software Development", slug: "/its-softwaredevelopment-115" },
    ],
  },
  {
    categoryName: "Intuit",
    categorySlug: "/intuit",
    courses: [
      { name: "QuickBooks Certified User Online", slug: "/intuit-quickbooks-101" },
      { name: "Bookkeeping Professional", slug: "/intuit-bookkeeping-102" },
      { name: "Personal Finance", slug: "/intuit-personalfinance-103" },
      { name: "Design Delight", slug: "/intuit-designdelight-104" }
    ],
  },
  {
    categoryName: "Microsoft Certified Fundamentals",
    categorySlug: "/mcf",
    courses: [
      { name: "Azure Fundamentals (AZ-900)", slug: "/mcf-azurefundamentals-101" },
      { name: "365 Fundamentals (MS-900)", slug: "/mcf-365fundamentals-102" },
      { name: "Azure AI Fundamentals (AI-900)", slug: "/mcf-azureaifundamentals-103" },
      { name: "Azure Data Fundamentals (DP-900)", slug: "/mcf-datafundamentals-104" },
      { name: "Power Platform Fundamentals (PL-900)", slug: "/mcf-powerplatformfundamentals-105" },
      { name: "Dynamics 365 Fundamentals CRM (MB-910)", slug: "/mcf-dynamics365fundamentalscrm-106" },
      { name: "Dynamics 365 Fundamentals ERP (MB-920)", slug: "/mcf-dynamics365fundamentalserp-107" },
      { name: "Security Compliance (SC-900)", slug: "/mcf-securitycompliance-108" },
    ],
  },
  {
    categoryName: "Microsoft Office Specialist",
    categorySlug: "/mos",
    courses: [
      { name: "Excel Expert", slug: "/mos-excelexpert-101" },
      { name: "Word Expert", slug: "/mos-wordexpert-102" },
      { name: "PowerPoint Associate", slug: "/mos-powerpoint-103" },
      { name: "Excel Associate", slug: "/mos-excelassociate-104" },
      { name: "Word Associate", slug: "/mos-wordassociate-105" }
    ],
  },
  {
    categoryName: "Unity Certified User",
    categorySlug: "/unity",
    courses: [
      { name: "Programmer Certification", slug: "/unity-programmer-101" },
      { name: "VR Developer Certification", slug: "/unity-vrdeveloper-102" },
      { name: "Artist Certification", slug: "/unity-artist-103" }
    ],
  },
];

export default courseData;
