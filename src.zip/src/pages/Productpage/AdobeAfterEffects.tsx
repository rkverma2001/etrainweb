import DownloadButton from "@/components/button/DownloadButton";
import Navbar from "@/components/navbar/Navbar";
import { FaLaptop, FaMinus, FaPlus } from "react-icons/fa";
import Ratings from "@/components/reviews/Ratings";
import { useEffect, useState } from "react";
import Footer from "@/components/footer/Footer";
import ExamVoucher from "./ExamVoucher";
import { Card } from "@/components/ui/card";
import PracticeVoucher from "./PracticeVoucher";
import Courseware from "./Courseware";
import Testimonials from "@/components/testimonials/Testimonials";

type TabName = "Bundle" | "Exam Voucher" | "Practice Test" | "Courseware";
type TabContent = {
  title: string;
  subtitle: string;
  image: string;
  price: number;
};

const AdobeAfterEffects = () => {
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if ("scrollRestoration" in window.history) {
      window.history.scrollRestoration = "manual";
    }
    window.scrollTo(0, 0);
  }, []);

  const pricePerItem = 3849;
  const tabs = ["Bundle", "Exam Voucher", "Practice Test", "Courseware"];
  const [activeTab, setActiveTab] = useState<TabName>("Bundle");

  const tabData: Record<TabName, TabContent> = {
    "Bundle": {
      title: "Adobe Certified Professional\nAfter Effects\nBest Value Bundle",
      subtitle: "Official Adobe Certification for Designers & Editors",
      image:
        "/CoursesCategories/AdobeProductImages/adobeaftereffectsbundle.svg",
      price: 3849,
    },
    "Exam Voucher": {
      title: "Adobe Certified Professional\nAfter Effects\nExam Voucher",
      subtitle: "Official Adobe Certification for Designers & Editors",
      image: "/CoursesCategories/AdobeProductImages/adobePIae.svg",
      price: 2199,
    },
    "Practice Test": {
      title: "Adobe Certified Professional\nAfter Effects\nPractice Test",
      subtitle: "Be Exam-Ready with CertPREP Practice Tests",
      image: "/CoursesCategories/AdobeProductPracticeTestImages/adobePIae.svg",
      price: 999,
    },
    Courseware: {
      title: "Adobe Certified Professional\nAfter Effects\nE-Learning Course",
      subtitle: "Self-paced learning content from Adobe",
      image: "/CoursesCategories/AdobeLearningImages/adobePIae.svg",
      price: 1299,
    },
  };

  const curriculumData = [
      {
        question: "MODULE 1 \u00A0\u00A0|\u00A0\u00A0 1 HOUR",
        answers: [
          "Working in the Visual Effects and Motion Graphics Industry",
          "Purpose, Audience, and Communication",
          "Copyright, Permissions, and Licensing; Video Production Principles",
          "Visual Effects and Design Principles",
        ],
      },
      {
        question: "MODULE 2 \u00A0\u00A0|\u00A0\u00A0 1 HOUR",
        answers: [
          "Project Setup and Interface",
          "Creating a Project",
          "Organizing and Customizing Workspaces",
          "Non-Visible Design Tools",
          "Import and Manage Assets",
        ],
      },
      {
        question: "MODULE 3 \u00A0\u00A0|\u00A0\u00A0 49 MINUTES",
        answers: [
          "Organizing Projects",
          "Use the Timeline Panel",
          "Manage Layers",
          "Modify Layer Visibility",
        ],
      },
      {
        question: "MODULE 4 \u00A0\u00A0|\u00A0\u00A0 2 HOURS",
        answers: [
          "Creating and Modifying Visual Elements",
          "Use Core Tools to Create Content",
          "Add and Animate Text",
          "Adjust Footage in Compositions",
          "Modify and Manipulate Digital Video",
          "Apply and Adjust Effects",
          "Create Composites",
          "Apply and Modify Effects and Presets",
          "Create and Modify Keyframes",
        ],
      },
      {
        question: "MODULE 5 \u00A0\u00A0|\u00A0\u00A0 39 MINUTES",
        answers: [
          "Publishing Digital Media",
          "Prepare Compositions for Publishing",
          "Export a Project",
        ],
      },
    ];

  const testimonialData = [
    {
      message:
        "Excited to announce my graduation 🎓 from the UX Career Acceleration Program by GrowthSchool under the mentorship of Anudeep Ayyagari (UX Anudeep). It's been an enriching journey exploring UX concepts, design tools 🎨, and the realm of product design. Collaborating with talented peers, we've delved into crafting ...",
      name: "Abhishika K.N",
      role: "Engineer - 2 - Version",
      image: "https://i.ibb.co/jJmYtTp/1.jpg",
    },
    {
      message:
        "Excited to announce my graduation 🎓 from the UX Career Acceleration Program by GrowthSchool under the mentorship of Anudeep Ayyagari (UX Anudeep). It's been an enriching journey exploring UX concepts, design tools 🎨, and the realm of product design. Collaborating with talented peers, we've delved into crafting ...",
      name: "Rahul Sharma",
      role: "UI/UX Designer - TechCorp",
      image: "https://i.ibb.co/jJmYtTp/1.jpg",
    },
    {
      message:
        "Excited to announce my graduation 🎓 from the UX Career Acceleration Program by GrowthSchool under the mentorship of Anudeep Ayyagari (UX Anudeep). It's been an enriching journey exploring UX concepts, design tools 🎨, and the realm of product design. Collaborating with talented peers, we've delved into crafting ...",
      name: "Ritesh Kumar Verma",
      role: "Software Engineer - TechCorp",
      image: "https://i.ibb.co/jJmYtTp/1.jpg",
    },
    {
      message:
        "Excited to announce my graduation 🎓 from the UX Career Acceleration Program by GrowthSchool under the mentorship of Anudeep Ayyagari (UX Anudeep). It's been an enriching journey exploring UX concepts, design tools 🎨, and the realm of product design. Collaborating with talented peers, we've delved into crafting ...",
      name: "Ritesh Verma",
      role: "Software Developer - TechCorp",
      image: "https://i.ibb.co/jJmYtTp/1.jpg",
    },
  ];

  const videoData = {
    videoUrl: "/videos/VideoAe.mp4",
  };

  const highlights = [
    "Working in the Visual Effects and Motion Graphics Industry",
    "Project Setup and Interface",
    "Organizing Projects",
    "Creating and Modifying Visual Elements",
    "Publishing Digital Media",
  ];

  const decrement = () => {
    if (quantity > 1) setQuantity(quantity - 1);
  };

  const increment = () => {
    setQuantity(quantity + 1);
  };

  const formatPrice = (num: number) => {
    return num.toLocaleString("en-IN");
  };

  const totalPrice = pricePerItem * quantity;

  return (
    <div className="">
      <Navbar onLoginClick={() => console.log("login clicked")} />

      <div className="flex justify-center border-b border-gray-200 gap-28 items-center ml-[120px] mr-[150px] pb-1 mt-[100px] mb-[-20px] px-14">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as TabName)}
            className="relative text-gray-700 text-lg pb-2 transition-all ease-linear cursor-pointer"
          >
            {tab}
            {activeTab === tab && (
              <span className="absolute left-0 bottom-0 w-full mb-[-5px] h-[2px] bg-blue-600 rounded"></span>
            )}
          </button>
        ))}
      </div>

      <div className="flex pl-14 pr-14 pb-14 relative z-10 md:flex-row">
        <div className="flex items-center  justify-center w-[75%] md:items-start md:justify-start">
          <div className="flex flex-col items-center justify-center">
            <img
              src={tabData[activeTab].image}
              className="mt-[74px] ml-[65px] h-66 border rounded-2xl"
              alt="IT Specialist Certification Logo"
            />
          </div>
          <div className="flex flex-col  justify-center md:mt-0 md:ml-10">
            <h1 className="text-[2.5rem] font-semibold gap-10 leading-12 ml-3 mt-[65px] whitespace-pre-line">
              {tabData[activeTab].title}
            </h1>
            <p className="text font-light ml-[12px]  mt-[10px]">
              {tabData[activeTab].subtitle}
            </p>
            <div className="ml-[12px] mt-[5px]">
              <Ratings />
            </div>
            {activeTab === "Bundle" && (
              <div className="ml-[12px] mt-[20px]">
                <DownloadButton />
              </div>
            )}
            {activeTab === "Practice Test" && (
              <div className="ml-[12px] mt-[20px]">
                <button
                  className="flex items-center gap-2 text-white px-4 py-2 rounded-lg shadow hover:opacity-90 cursor-pointer"
                  style={{ backgroundColor: "#0b8642" }}
                >
                  <p className="font-extralight">Explore More</p>
                </button>
              </div>
            )}
            {activeTab === "Exam Voucher" && (
              <div className="ml-[12px] mt-[20px]">
                <DownloadButton />
              </div>
            )}
            {activeTab === "Courseware" && (
              <div className="ml-[12px] mt-[20px]">
                <DownloadButton />
              </div>
            )}
          </div>
        </div>
        <div className="flex flex-col w-[25%] items-center justify-center md:mt-0 md:ml-10">
          <div className=" h-[310px] w-[300px] bg-white rounded-xl  justify-center mt-[60px] ml-[-150px]">
            <div className="ml-[25px] mt-[5px] flex justify-between">
              <div className="ml-[-1px] mt-[3px] font-light">PRICE</div>
              <div className="flex items-center justify-center text-xs text-blue-600 font-semibold mb-1 mr-[20px]">
                <FaLaptop className="mr-1" />
                DIGITAL PRODUCT
              </div>
            </div>
            <div className="text-green-600 font-semibold text-xl ml-[25px]">
              ₹ {formatPrice(tabData[activeTab].price)}
            </div>
            <div className="ml-[25px] mt-[15px] font-light">QUANTITY</div>
            <div className="flex mt-2">
              <div className="flex items-center ml-[25px] border rounded">
                <button onClick={decrement} className="p-3 cursor-pointer">
                  <FaMinus className="w-3 h-3" />
                </button>

                <div className="px-2 py-1 text-center min-w-[10px]">
                  {quantity}
                </div>

                <button onClick={increment} className="p-3 cursor-pointer">
                  <FaPlus className="w-3 h-3" />
                </button>
              </div>
            </div>

            <div className="ml-[25px] mt-[20px] flex justify-between">
              <div className="font-light">Product Total</div>
              <div className="font-light mr-[20px]">
                ₹ {formatPrice(totalPrice)}
              </div>
            </div>
            <div className="ml-[25px] mt-[5px] flex justify-between">
              <div className="font-light">Grand Total</div>
              <div className="font-light mr-[20px]">
                ₹ {formatPrice(totalPrice)}
              </div>
            </div>
            <div className="ml-[25px] mt-[5px] flex justify-between">
              <button
                className="flex items-center mt-[15px] gap-2 text-white px-5 py-2 rounded-lg shadow hover:opacity-90 cursor-pointer"
                style={{ backgroundColor: "#0b8642" }}
              >
                Add to cart
              </button>
              <button
                className="flex items-center mt-[15px] mr-[20px] gap-2 text-white px-7 py-2 rounded-lg shadow hover:opacity-90 cursor-pointer"
                style={{ backgroundColor: "#0b8642" }}
              >
                Buy Now
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col items-center justify-center mt-[-45px]">
        <div className="text-3xl mt-[25px] font-semibold text-[#17345b]">
          What's Included
          <img
            src="/Icon/line.svg"
            alt="line"
            className="pl-[100px] w-56 mt-[-5px]"
          />
        </div>
        <div className="flex items-center justify-center mt-10">
          {activeTab === "Bundle" && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 place-items-center">
              <Card className="w-full max-w-xl p-5 transition-all duration-300 ease-in-out hover:scale-105 shadow-[0_0_10px_rgba(0,0,0,0.2)] items-center">
                <div className="flex items-center gap-6 w-full">
                  <div className="w-1/5">
                    <img
                      src="/Icon/Learning_Course_Card_Icon_green.svg"
                      alt="Learning Icon"
                      className="w-full h-20 object-contain"
                    />
                  </div>
                  <div className="w-4/5 flex flex-col items-start">
                    <h2 className="text-lg text-gray-800">
                      Self-Paced E-Learning Course
                    </h2>
                  </div>
                </div>
              </Card>
              <Card className="w-full max-w-xl p-[30px] transition-all duration-300 ease-in-out hover:scale-105 shadow-[0_0_10px_rgba(0,0,0,0.2)] items-center">
                <div className="flex items-center gap-6 w-full">
                  <div className="w-1/5">
                    <img
                      src="/Icon/Practice_Test_Card_Icon_Green.svg"
                      alt="Learning Icon"
                      className="w-full h-15 object-contain"
                    />
                  </div>
                  <div className="w-4/5 flex flex-col items-start">
                    <h2 className="text-lg text-gray-800">
                      Official Practice Test
                    </h2>
                  </div>
                </div>
              </Card>
              <Card className="w-full max-w-xl p-5 transition-all duration-300 ease-in-out hover:scale-105 shadow-[0_0_10px_rgba(0,0,0,0.2)] items-center">
                <div className="flex items-center gap-6 w-full">
                  <div className="w-1/5">
                    <img
                      src="/Icon/Certification_Card_Icon_Green.svg"
                      alt="Learning Icon"
                      className="w-full h-20 pt-[15px] object-contain"
                    />
                  </div>
                  <div className="w-4/5 flex flex-col items-start">
                    <h2 className="text-lg text-gray-800">
                      Official Exam Voucher
                    </h2>
                  </div>
                </div>
              </Card>
            </div>
          )}
          {activeTab === "Exam Voucher" && (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 gap-6 place-items-center">
              <Card className="w-full max-w-xl p-5 transition-all duration-300 ease-in-out hover:scale-105 shadow-[0_0_10px_rgba(0,0,0,0.2)] items-center">
                <div className="flex items-center gap-6 w-full">
                  <div className="w-1/5">
                    <img
                      src="/Icon/Certification_Card_Icon_Green.svg"
                      alt="Learning Icon"
                      className="w-full h-20 pt-[15px] object-contain"
                    />
                  </div>
                  <div className="w-4/5 flex flex-col items-start">
                    <h2 className="text-lg text-gray-800">
                      Official Exam Voucher
                    </h2>
                  </div>
                </div>
              </Card>
              <Card className="w-full max-w-xl p-[30px] transition-all duration-300 ease-in-out hover:scale-105 shadow-[0_0_10px_rgba(0,0,0,0.2)] items-center">
                <div className="flex items-center gap-6 w-full">
                  <div className="w-1/5">
                    <img
                      src="/Icon/proctor.svg"
                      alt="Learning Icon"
                      className="w-full h-15 object-contain"
                    />
                  </div>
                  <div className="w-4/5 flex flex-col items-start">
                    <h2 className="text-lg text-gray-800">Remote Proctoring</h2>
                  </div>
                </div>
              </Card>
            </div>
          )}
          {activeTab === "Practice Test" && (
            <div>
              <Card className="w-full max-w-xl p-5 transition-all duration-300 ease-in-out hover:scale-105 shadow-[0_0_10px_rgba(0,0,0,0.2)] items-center">
                <div className="flex items-center gap-4 w-full">
                  <div className="w-1/5">
                    <img
                      src="/Icon/Practice_Test_Card_Icon_Green.svg"
                      alt="Learning Icon"
                      className="w-full h-15 object-contain"
                    />
                  </div>
                  <div className="w-4/5 flex flex-col items-start">
                    <h2 className="text-lg text-gray-800">
                      Official Practice Test Voucher
                    </h2>
                  </div>
                </div>
              </Card>
            </div>
          )}
          {activeTab === "Courseware" && (
            <div>
              <Card className="w-full max-w-xl p-5 transition-all duration-300 ease-in-out hover:scale-105 shadow-[0_0_10px_rgba(0,0,0,0.2)] items-center">
                <div className="flex items-center gap-2 w-full">
                  <div className="w-1/5">
                    <img
                      src="/Icon/Learning_Course_Card_Icon_green.svg"
                      alt="Learning Icon"
                      className="w-full h-14 object-contain"
                    />
                  </div>
                  <div className="w-4/5 flex flex-col items-start">
                    <h2 className="text-lg text-gray-800">
                      Self-Paced E-Learning Course
                    </h2>
                  </div>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
      <div className="w-full relative mb-[-25px] mt-[10px]">
        <img
          src="https://cdn.prod.website-files.com/62e8d2ea218fb7676b6892a6/67177e886c499c85bf94cc36_top%20curv.svg"
          alt="Curved Top Border"
          className="w-full h-auto block"
        />
      </div>
      {activeTab === "Bundle" && (
        <div className="flex flex-row justify-between mt-[80px] ">
          <div className="text-7xl font-semibold mt-[25px] text-[#17345b] ml-[130px] leading-[80px] ">
            Why <br /> This
            <br /> Certification
          </div>
          <div className="mr-[150px] mt-[35px]">
            <div className="flex flex-row mt-[10px]">
              <div className="flex flex-col w-10 h-10 relative justify-between">
                <img src="/Icon/boost_Badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[px] ml-[15px]">
                Boost Career Prospects
              </p>
            </div>
            <div className="flex flex-row mt-[40px]">
              <div className="flex flex-col w-8 h-8 relative justify-between">
                <img src="/Icon/recognized_badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[3px] ml-[25px]">
                Recognized by Top Employers & Design Studios
              </p>
            </div>
            <div className="flex flex-row mt-[50px]">
              <div className="flex flex-col w-10 h-10 relative justify-between">
                <img src="/Icon/verified_badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[2px] ml-[18px]">
                Validates Your After Effects Skills Officially
              </p>
            </div>
          </div>
        </div>
      )}
      {activeTab === "Exam Voucher" && (
        <div className="flex flex-row justify-between mt-[80px]">
          <div className="text-7xl font-semibold mt-[25px] text-[#17345b] ml-[130px] leading-[80px] ">
            Why <br /> This
            <br /> Certification
          </div>
          <div className="mr-[150px] mt-[35px]">
            <div className="flex flex-row mt-[10px]">
              <div className="flex flex-col w-10 h-10 relative justify-between">
                <img src="/Icon/boost_Badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[px] ml-[15px]">
                Boost Career Prospects
              </p>
            </div>
            <div className="flex flex-row mt-[40px]">
              <div className="flex flex-col w-8 h-8 relative justify-between">
                <img src="/Icon/recognized_badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[3px] ml-[25px]">
                Recognized by Top Employers & Design Studios
              </p>
            </div>
            <div className="flex flex-row mt-[50px]">
              <div className="flex flex-col w-10 h-10 relative justify-between">
                <img src="/Icon/verified_badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[2px] ml-[18px]">
                Validates Your After Effects Skills Officially
              </p>
            </div>
          </div>
        </div>
      )}
      {activeTab === "Practice Test" && (
        <div className="flex flex-row justify-between mt-[80px]">
          <div className="text-7xl font-semibold mt-[68px] text-[#17345b] ml-[130px] leading-[80px] ">
            Why <br /> CertPREP
            <br /> Practice Tests
          </div>
          <div className="mr-[150px]">
            <div className="flex flex-row mt-[10px]">
              <div className="">
                <img
                  src="/Icon/pt1.svg"
                  alt=""
                  className="w-12 h-12 mt-[3px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl">Simulates Real Exam</p>
                <p className="font-light">
                  Experience the actual testing interface before exam day
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px] ">
              <div className="">
                <img
                  src="/Icon/pt2.svg"
                  alt="boost"
                  className="w-12 h-12 mt-[4px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl">Boosts Exam Confidence</p>
                <p className="font-light">
                  Practice until you feel fully ready
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px]">
              <div className="">
                <img
                  src="/Icon/pt3.svg"
                  alt=""
                  className="w-12 h-12 mt-[7px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl mt-[2px]">Flexible Practice Modes</p>
                <p className="font-light">
                  Choose between Training and Testing modes
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px]">
              <div className="">
                <img
                  src="/Icon/pt4.svg"
                  alt=""
                  className="w-12 h-12 mt-[6px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl mt-[2px]">Higher Chances of Passing</p>
                <p className="font-light">Target and Strenthen weak areas</p>
              </div>
            </div>
          </div>
        </div>
      )}
      {activeTab === "Courseware" && (
        <div className="flex flex-row justify-between mt-[80px]">
          <div className="text-7xl font-semibold mt-[68px] text-[#17345b] ml-[130px] leading-[80px] ">
            Why <br /> Choose
            <br /> LearnKey
          </div>
          <div className="mr-[100px]">
            <div className="flex flex-row mt-[10px]">
              <div className="">
                <img
                  src="/Icon/lk1.svg"
                  alt=""
                  className="w-12 h-12 mt-[3px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl">24/7 Online Access</p>
                <p className="font-light">
                  Learn Anytime, Anywhere with On-demand Training Videos
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px] ">
              <div className="">
                <img
                  src="/Icon/lk2.svg"
                  alt="boost"
                  className="w-12 h-12 mt-[4px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl">Hands On Projects</p>
                <p className="font-light">
                  Apply Your Skills Through Real-World Exercises
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px]">
              <div className="">
                <img
                  src="/Icon/lk3.svg"
                  alt=""
                  className="w-12 h-12 mt-[7px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl mt-[2px]">Seamless Experience</p>
                <p className="font-light">
                  Delivered on the GMetrix Platform Ensuring Smooth Access
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px]">
              <div className="">
                <img
                  src="/Icon/recognized_badge.svg"
                  alt=""
                  className="w-12 h-12 mt-[6px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl mt-[2px]">Industry Recognition</p>
                <p className="font-light">Industry Approved Courseware</p>
              </div>
            </div>
          </div>
        </div>
      )}
      <div className="w-full relative mt-[80px]">
        <img
          src="https://cdn.prod.website-files.com/62e8d2ea218fb7676b6892a6/67177e883ea6a4d457e262f3_bottom%20curve.svg"
          alt="Curved Top Border"
          className="w-full h-auto block"
        />
      </div>
      {activeTab === "Exam Voucher" && (
        <div>
          <ExamVoucher highlights={highlights} videoSrc={videoData.videoUrl} />
        </div>
      )}
      {activeTab === "Practice Test" && (
        <div>
          <PracticeVoucher videoSrc={videoData.videoUrl} />
        </div>
      )}
      {activeTab === "Courseware" && (
        <div>
          <Courseware curriculumData={curriculumData} />
        </div>
      )}
      {activeTab === "Courseware" && (
        <div
          className="w-full h-screen bg-cover bg-center flex flex-col items-center justify-center"
          style={{ backgroundImage: "url('/Icon/bgsection.svg')" }}
        >
          {/* Heading */}
          <h1 className="text-white font-semibold text-4xl mb-10">
            Sneek Peek Into Courseware
          </h1>

          {/* YouTube Embed */}
          <iframe
            width="600"
            height="340"
            src="https://www.youtube.com/embed/cxALQqiKmMQ?si=h7Kg94pYcMrGiHU_"
            title="YouTube video player"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerPolicy="strict-origin-when-cross-origin"
            allowFullScreen
            className="rounded-lg shadow-lg relative"
          ></iframe>
        </div>
      )}
      {activeTab === "Exam Voucher" && (
        <div className="flex items-center justify-between mt-[80px] ">
          <div>
            <h1 className="text-2xl ml-[130px] mt-[80px] font-light">
              You will be officially certified by{" "}
              <span className="text-[#ed2224] font-bold">Adobe</span>
            </h1>

            <img
              src="/AfterEffectsCertificate.svg"
              alt=""
              className="w-[600px] mt-10 ml-[120px]"
            />
          </div>

          <div className="relative h-88 mt-[-40px] mr-[110px]">
            <img src="/Flaunt.svg" alt="Certification Banner" className="" />
          </div>
        </div>
      )}
      {activeTab === "Bundle" && (
        <div className="flex flex-col items-center justify-center mt-[80px]">
          <img src="/Icon/steps_banner.svg" alt="steps_banner" />
        </div>
      )}
      {activeTab === "Exam Voucher" && (
        <div className="flex flex-col items-center justify-center mt-[80px]">
          <img src="/Icon/certibanner.svg" alt="banner_exam" />
        </div>
      )}
      {activeTab === "Practice Test" && (
        <div className="flex flex-col items-center justify-center mt-[80px]">
          <img src="/Icon/practicebanner.svg" alt="banner_practice" />
        </div>
      )}
      {activeTab === "Courseware" && (
        <div className="flex flex-col items-center justify-center">
          <img src="/Icon/lkbanner.svg" alt="banner_practice" />
        </div>
      )}
      <div className="mt-[50px]">
        <Testimonials data={testimonialData} />
      </div>

      <div className="">
        <Footer />
      </div>
    </div>
  );
};

export default AdobeAfterEffects;
