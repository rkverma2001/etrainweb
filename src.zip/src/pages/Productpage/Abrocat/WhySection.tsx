import React from "react";

interface WhySectionProps {
  activeTab: string;
}

const WhySection: React.FC<WhySectionProps> = ({ activeTab }) => {
  return (
    <div>
      {activeTab === "Bundle" && (
        <div className="flex flex-row justify-between mt-[80px] ">
          <div className="text-7xl font-semibold mt-[25px] text-[#17345b] ml-[130px] leading-[80px] ">
            Why <br /> This
            <br /> Certification
          </div>
          <div className="mr-[150px] mt-[35px]">
            <div className="flex flex-row mt-[10px]">
              <div className="flex flex-col w-10 h-10 relative justify-between">
                <img src="/Icon/boost_Badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[px] ml-[15px]">
                Boost Career Prospects
              </p>
            </div>
            <div className="flex flex-row mt-[40px]">
              <div className="flex flex-col w-8 h-8 relative justify-between">
                <img src="/Icon/recognized_badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[3px] ml-[25px]">
                Recognized by Top Employers & Companies
              </p>
            </div>
            <div className="flex flex-row mt-[50px]">
              <div className="flex flex-col w-10 h-10 relative justify-between">
                <img src="/Icon/verified_badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[2px] ml-[18px]">
                Validates Your Skills Officially
              </p>
            </div>
          </div>
        </div>
      )}
      {activeTab === "Exam Voucher" && (
        <div className="flex flex-row justify-between mt-[80px]">
          <div className="text-7xl font-semibold mt-[25px] text-[#17345b] ml-[130px] leading-[80px] ">
            Why <br /> This
            <br /> Certification
          </div>
          <div className="mr-[150px] mt-[35px]">
            <div className="flex flex-row mt-[10px]">
              <div className="flex flex-col w-10 h-10 relative justify-between">
                <img src="/Icon/boost_Badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[px] ml-[15px]">
                Boost Career Prospects
              </p>
            </div>
            <div className="flex flex-row mt-[40px]">
              <div className="flex flex-col w-8 h-8 relative justify-between">
                <img src="/Icon/recognized_badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[3px] ml-[25px]">
                Recognized by Top Employers & Companies
              </p>
            </div>
            <div className="flex flex-row mt-[50px]">
              <div className="flex flex-col w-10 h-10 relative justify-between">
                <img src="/Icon/verified_badge.svg" alt="" />
              </div>
              <p className="text-2xl mt-[2px] ml-[18px]">
                Validates Your Skills Officially
              </p>
            </div>
          </div>
        </div>
      )}
      {activeTab === "Practice Test" && (
        <div className="flex flex-row justify-between mt-[80px]">
          <div className="text-7xl font-semibold mt-[68px] text-[#17345b] ml-[130px] leading-[80px] ">
            Why <br /> CertPREP
            <br /> Practice Tests
          </div>
          <div className="mr-[150px]">
            <div className="flex flex-row mt-[10px]">
              <div className="">
                <img
                  src="/Icon/pt1.svg"
                  alt=""
                  className="w-12 h-12 mt-[3px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl">Simulates Real Exam</p>
                <p className="font-light">
                  Experience the actual testing interface before exam day
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px] ">
              <div className="">
                <img
                  src="/Icon/pt2.svg"
                  alt="boost"
                  className="w-12 h-12 mt-[4px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl">Boosts Exam Confidence</p>
                <p className="font-light">
                  Practice until you feel fully ready
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px]">
              <div className="">
                <img
                  src="/Icon/pt3.svg"
                  alt=""
                  className="w-12 h-12 mt-[7px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl mt-[2px]">Flexible Practice Modes</p>
                <p className="font-light">
                  Choose between Training and Testing modes
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px]">
              <div className="">
                <img
                  src="/Icon/pt4.svg"
                  alt=""
                  className="w-12 h-12 mt-[6px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl mt-[2px]">Higher Chances of Passing</p>
                <p className="font-light">Target and Strenthen weak areas</p>
              </div>
            </div>
          </div>
        </div>
      )}
      {activeTab === "Courseware" && (
        <div className="flex flex-row justify-between mt-[80px]">
          <div className="text-7xl font-semibold mt-[68px] text-[#17345b] ml-[130px] leading-[80px] ">
            Why <br /> Choose
            <br /> LearnKey
          </div>
          <div className="mr-[100px]">
            <div className="flex flex-row mt-[10px]">
              <div className="">
                <img
                  src="/Icon/lk1.svg"
                  alt=""
                  className="w-12 h-12 mt-[3px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl">24/7 Online Access</p>
                <p className="font-light">
                  Learn Anytime, Anywhere with On-demand Training Videos
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px] ">
              <div className="">
                <img
                  src="/Icon/lk2.svg"
                  alt="boost"
                  className="w-12 h-12 mt-[4px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl">Hands On Projects</p>
                <p className="font-light">
                  Apply Your Skills Through Real-World Exercises
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px]">
              <div className="">
                <img
                  src="/Icon/lk3.svg"
                  alt=""
                  className="w-12 h-12 mt-[7px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl mt-[2px]">Seamless Experience</p>
                <p className="font-light">
                  Delivered on the GMetrix Platform Ensuring Smooth Access
                </p>
              </div>
            </div>

            <div className="flex flex-row mt-[40px]">
              <div className="">
                <img
                  src="/Icon/recognized_badge.svg"
                  alt=""
                  className="w-12 h-12 mt-[6px]"
                />
              </div>
              <div className="ml-[20px]">
                <p className="text-2xl mt-[2px]">Industry Recognition</p>
                <p className="font-light">Industry Approved Courseware</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WhySection;
