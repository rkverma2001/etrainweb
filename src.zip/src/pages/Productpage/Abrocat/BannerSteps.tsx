import React from "react";

interface BannerStepsProps {
  activeTab: string;
}

const BannerSteps: React.FC<BannerStepsProps> = ({ activeTab }) => {
  return (
    <div>
      {activeTab === "Bundle" && (
        <div className="flex flex-col items-center justify-center mt-[80px]">
        <img src="/Icon/steps_banner.svg" alt="steps_banner" />
        </div>
      )}

      {activeTab === "Exam Voucher" && (
        <div className="flex flex-col items-center justify-center mt-[80px]">
          <img src="/Icon/certibanner.svg" alt="banner_exam" />
        </div>
      )}

      {activeTab === "Practice Test" && (
        <div className="flex flex-col items-center justify-center mt-[80px]">
          <img src="/Icon/practicebanner.svg" alt="banner_practice" />
        </div>
      )}

      {activeTab === "Courseware" && (
        <div className="flex flex-col items-center justify-center">
          <img src="/Icon/lkbanner.svg" alt="banner_courseware" />
        </div>
      )}
    </div>
  );
};

export default BannerSteps;
