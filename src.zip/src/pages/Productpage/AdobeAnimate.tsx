import DownloadButton from "@/components/button/DownloadButton";
import { FaLaptop, FaMinus, FaPlus } from "react-icons/fa";
import Ratings from "@/components/reviews/Ratings";
import { useState } from "react";
import Footer from "@/components/footer/Footer";
import Navbar from "@/components/navbar/Navbar";
import Testimonials from "@/components/testimonials/Testimonials";

type TabName = "Bundle" | "Exam Voucher" | "Practice Test" | "E-Learning";
type TabContent = {
  title: string;
  subtitle: string;
  image: string;
  price: number;
};

const AdobeAnimate = () => {
  const [quantity, setQuantity] = useState(1);
  const pricePerItem = 3849;
  const tabs = ["Bundle", "Exam Voucher", "Practice Test", "E-Learning"];
  const [activeTab, setActiveTab] = useState<TabName>("Bundle");

  const tabData: Record<TabName, TabContent> = {
    Bundle: {
      title: "Adobe Certified Professional\nAnimate\nBest Value Bundle",
      subtitle: "Official Adobe Certification for Designers & Editors",
      image: "/CoursesCategories/AdobeProductImages/Animate.svg",
      price: 3849,
    },
    "Exam Voucher": {
      title: "Adobe Certified Professional\nAnimate\nExam Voucher",
      subtitle: "Get certified with Adobe's official exam voucher",
      image: "/CoursesCategories/AdobeProductImages/adobePIan.svg",
      price: 2149,
    },
    "Practice Test": {
      title: "Adobe Certified Professional\nAnimate\nPractice Test",
      subtitle: "Sharpen your skills before the big day",
      image: "/CoursesCategories/AdobeProductPracticeTestImages/adobePIan.svg",
      price: 999,
    },
    "E-Learning": {
      title: "Adobe Certified Professional\nAnimate\nE-Learning",
      subtitle: "Self-paced learning content from Adobe",
      image: "/CoursesCategories/AdobeLearningImages/adobePIan.svg",
      price: 1299,
    },
  };

  const testimonialData = [
    {
      message:
        "Excited to announce my graduation 🎓 from the UX Career Acceleration Program by GrowthSchool under the mentorship of Anudeep Ayyagari (UX Anudeep). It's been an enriching journey exploring UX concepts, design tools 🎨, and the realm of product design. Collaborating with talented peers, we've delved into crafting ...",
      name: "Abhishika K.N",
      role: "Engineer - 2 - Version",
      image: "https://i.ibb.co/jJmYtTp/1.jpg",
    },
    {
      message:
        "Excited to announce my graduation 🎓 from the UX Career Acceleration Program by GrowthSchool under the mentorship of Anudeep Ayyagari (UX Anudeep). It's been an enriching journey exploring UX concepts, design tools 🎨, and the realm of product design. Collaborating with talented peers, we've delved into crafting ...",
      name: "Rahul Sharma",
      role: "UI/UX Designer - TechCorp",
      image: "https://i.ibb.co/jJmYtTp/1.jpg",
    },
    {
      message:
        "Excited to announce my graduation 🎓 from the UX Career Acceleration Program by GrowthSchool under the mentorship of Anudeep Ayyagari (UX Anudeep). It's been an enriching journey exploring UX concepts, design tools 🎨, and the realm of product design. Collaborating with talented peers, we've delved into crafting ...",
      name: "Ritesh Kumar Verma",
      role: "Software Engineer - TechCorp",
      image: "https://i.ibb.co/jJmYtTp/1.jpg",
    },
    {
      message:
        "Excited to announce my graduation 🎓 from the UX Career Acceleration Program by GrowthSchool under the mentorship of Anudeep Ayyagari (UX Anudeep). It's been an enriching journey exploring UX concepts, design tools 🎨, and the realm of product design. Collaborating with talented peers, we've delved into crafting ...",
      name: "Ritesh Verma",
      role: "Software Developer - TechCorp",
      image: "https://i.ibb.co/jJmYtTp/1.jpg",
    },
  ];

  const decrement = () => {
    if (quantity > 1) setQuantity(quantity - 1);
  };

  const increment = () => {
    setQuantity(quantity + 1);
  };

  const formatPrice = (num: number) => {
    return num.toLocaleString("en-IN");
  };

  const totalPrice = pricePerItem * quantity;

  return (
    <div className="relative overflow-hidden bg-white">
      <Navbar onLoginClick={() => console.log("Login clicked")} />
      <div className="flex justify-center">
        <div className="flex justify-between border-b border-gray-200 w-[80%] pt-26 lg:px-34 md:px-10">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as TabName)}
              className="relative text-gray-700 text-lg pb-1 transition-all cursor-pointer"
            >
              {tab}
              {activeTab === tab && (
                <span className="absolute left-0 bottom-0 w-full mb-[-1px] h-[2px] bg-blue-600 rounded"></span>
              )}
            </button>
          ))}
        </div>
      </div>
      <div className="flex justify-between items-center mx-14 md:mx-14 lg:mx-36  flex-col lg:flex-row">
        <div className="flex flex-col ml-4 lg:mt-[-35px] lg:flex-row pt-10 gap-4 lg:gap-12">
          <div className="">
            <img
              src={tabData[activeTab].image}
              className="h-66 border rounded-2xl"
              alt="IT Specialist Certification Logo"
            />
          </div>
          <div className="lg:mt-[-5px]">
            <h1 className="text-[2.5rem] font-semibold leading-12 whitespace-pre-line">
              {tabData[activeTab].title}
            </h1>
            <p className="text font-light mt-[10px]">
              {tabData[activeTab].subtitle}
            </p>
            <div className="mt-[5px]">
              <Ratings />
            </div>
            <div className="mt-[20px]">
              <DownloadButton />
            </div>
          </div>
        </div>

        <div className="lg:pt-[45px] pt-10">
          <div className=" h-[310px] w-[300px] bg-white rounded-xl">
            <div className="ml-[25px] mt-[5px] flex justify-between">
              <div className="ml-[-1px] mt-[3px] font-light">PRICE</div>
              <div className="flex items-center justify-center text-xs text-blue-600 font-semibold mb-1 mr-[20px]">
                <FaLaptop className="mr-1" />
                DIGITAL PRODUCT
              </div>
            </div>
            <div className="text-green-600 font-semibold text-xl ml-[25px]">
              ₹ {tabData[activeTab].price}
            </div>
            <div className="ml-[25px] mt-[15px] font-light">QUANTITY</div>
            <div className="flex mt-2">
              <div className="flex items-center ml-[25px] border rounded">
                <button onClick={decrement} className="p-3 cursor-pointer">
                  <FaMinus className="w-3 h-3" />
                </button>

                <div className="px-2 py-1 text-center min-w-[10px]">
                  {quantity}
                </div>

                <button onClick={increment} className="p-3 cursor-pointer">
                  <FaPlus className="w-3 h-3" />
                </button>
              </div>
            </div>

            <div className="ml-[25px] mt-[20px] flex justify-between">
              <div className="font-light">Product Total</div>
              <div className="font-light mr-[20px]">
                ₹ {formatPrice(totalPrice)}
              </div>
            </div>
            <div className="ml-[25px] mt-[5px] flex justify-between">
              <div className="font-light">Grand Total</div>
              <div className="font-light mr-[20px]">
                ₹ {formatPrice(totalPrice)}
              </div>
            </div>
            <div className="ml-[25px] mt-[5px] flex justify-between">
              <button
                className="flex items-center mt-[15px] gap-2 text-white px-5 py-2 rounded-lg shadow hover:opacity-90 cursor-pointer"
                style={{ backgroundColor: "#0b8642" }}
              >
                Add to cart
              </button>
              <button
                className="flex items-center mt-[15px] mr-[20px] gap-2 text-white px-7 py-2 rounded-lg shadow hover:opacity-90 cursor-pointer"
                style={{ backgroundColor: "#0b8642" }}
              >
                Buy Now
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="flex flex-col bg-gray-100 items-center justify-center">
        <div className="text-3xl text-center mt-[25px] font-semibold text-[#17345b]">
          What's Included
        </div>
        <div className="flex justify-between w-full flex-col lg:flex-row mt-8 lg:px-30 mb-14">
          <div className="flex items-center pl-3">
            <div className="">
              <img
                src="/Icon/Learning_Course_Card_Icon_green.svg"
                alt="Learning Icon"
                className="h-14"
              />
            </div>
            <h2 className="text-xl ml-2 lg:ml-5 text-gray-800">
              Self-Paced E-Learning Course
            </h2>
          </div>
          <div className="flex items-center pl-5 mt-8">
            <div className="">
              <img
                src="/Icon/Practice_Test_Card_Icon_Green.svg"
                alt="Learning Icon"
                className="h-14"
              />
            </div>
            <h2 className="text-xl ml-3 text-gray-800">
              Practice Test
            </h2>
          </div>
          <div className="flex items-center pl-4 mt-6">
            <div className="mt-4">
              <img
                src="/Icon/Certification_Card_Icon_Green.svg"
                alt="Learning Icon"
                className="h-14"
              />
            </div>
            <h2 className="text-xl ml-4 text-gray-800">
              Official Certification
            </h2>
          </div>
        </div>
      </div>
      <div className="flex flex-row justify-between mt-[80px] ">
        <div className="lg:text-7xl text-5xl font-semibold mt-[25px] text-[#17345b] lg:ml-[130px] leading-[80px] ">
          Why <br /> This <br /> Certification
        </div>
        <div className="mr-[150px] mt-[35px]">
          <div className="flex flex-row mt-[10px]">
            <div className="flex flex-col w-10 h-10 relative justify-between">
              <img src="/Icon/boost_Badge.svg" alt="" />
            </div>
            <p className="text-2xl mt-[px] ml-[15px]">Boost Career Prospects</p>
          </div>
          <div className="flex flex-row mt-[40px]">
            <div className="flex flex-col w-8 h-8 relative justify-between">
              <img src="/Icon/recognized_badge.svg" alt="" />
            </div>
            <p className="text-2xl mt-[3px] ml-[25px]">
              Recognized by Top Employers & Design Studios
            </p>
          </div>
          <div className="flex flex-row mt-[50px]">
            <div className="flex flex-col w-10 h-10 relative justify-between">
              <img src="/Icon/verified_badge.svg" alt="" />
            </div>
            <p className="text-2xl mt-[2px] ml-[18px]">
              Validates Your After Effects Skills Officially
            </p>
          </div>
        </div>
      </div>
      <div className="flex flex-col items-center justify-center mt-[80px]">
        <img src="/Icon/steps_banner.svg" alt="steps_banner" />
      </div>
      <div className="mt-[50px]">
        <Testimonials data={testimonialData} />
      </div>
      <div></div>
      <div className="">
        <Footer />
      </div>
    </div>
  );
};

export default AdobeAnimate;
