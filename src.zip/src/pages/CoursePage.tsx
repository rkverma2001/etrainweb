import { useState } from "react";
import { BadgeCheck, Lock, GraduationCap, VideoIcon, CheckCircle } from "lucide-react";
import { FaStar } from "react-icons/fa";
import { Button } from "@/components/ui/button";
import Footer from "@/components/footer/Footer";
import Navbar from "@/components/navbar/Navbar";

const CoursePage = () => {

  const [activeTab, setActiveTab] = useState("Bundle");

  const renderTabContent = () => {
    switch (activeTab) {
      case "Bundle":
        return (
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4">ALL-IN-ONE PACKAGE</h2>
            <p className="text-gray-600 mb-4">Course, practice tests & certification exam</p>
            <div className="bg-gray-100 p-6 rounded-lg shadow-sm w-full max-w-md">
              <p className="font-semibold text-xl mb-2">All-In-One Package</p>
              <p className="text-gray-500 mb-2">Course, practice tests & certification exam</p>
              <p className="text-3xl font-bold text-gray-800 mb-4">₹ 22,000</p>
              <Button className="w-full bg-blue-600 text-white">Buy Bundle</Button>
            </div>
          </section>
        );
      case "Exam Voucher":
        return (
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4">Exam Voucher</h2>
            <div className="bg-gray-100 p-6 rounded-lg shadow-sm w-full max-w-md">
              <p className="font-semibold text-xl mb-2">CCNA 200-301 Exam Voucher</p>
              <p className="text-gray-500 mb-2">Official Pearson VUE exam code</p>
              <p className="text-3xl font-bold text-gray-800 mb-4">₹ 10,000</p>
              <Button className="w-full bg-blue-600 text-white">Buy Voucher</Button>
            </div>
          </section>
        );
      case "Practice Test":
        return (
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4">Practice Test</h2>
            <div className="bg-gray-100 p-6 rounded-lg shadow-sm w-full max-w-md">
              <p className="font-semibold text-xl mb-2">CCNA Practice Exam</p>
              <p className="text-gray-500 mb-2">200 timed questions with explanations</p>
              <p className="text-3xl font-bold text-gray-800 mb-4">₹ 2,000</p>
              <Button className="w-full bg-blue-600 text-white">Buy Practice Test</Button>
            </div>
          </section>
        );
      case "E-Learning Course":
        return (
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-4">E-Learning Course</h2>
            <div className="bg-gray-100 p-6 rounded-lg shadow-sm w-full max-w-md">
              <p className="font-semibold text-xl mb-2">Self-Paced CCNA Training</p>
              <p className="text-gray-500 mb-2">Video lectures, quizzes, and hands-on labs</p>
              <p className="text-3xl font-bold text-gray-800 mb-4">₹ 12,000</p>
              <Button className="w-full bg-blue-600 text-white">Buy E-learning Course</Button>
            </div>
          </section>
        );
      default:
        return null;
    }
  };

  return (
    <div>

      <Navbar onLoginClick={() => console.log("Login Clicked!")}/>
    <div className="p-4 mt-[60px] max-w-6xl mx-auto font-sans">
      {/* Header */}
      <header className="text-center my-10">
        <h1 className="text-4xl font-bold text-gray-800">Cisco Certified Network Associate (CCNA)</h1>
        <p className="text-lg text-gray-600 mt-2">Master network fundamentals and boost your IT career with official Cisco certification</p>
        <div className="mt-6 flex justify-center gap-4">
          <Button className="bg-blue-600 text-white text-lg px-6 py-2">Buy Now</Button>
          <Button variant="outline" className="text-lg px-6 py-2">Free Preview Lesson</Button>
        </div>
        <div className="mt-4 flex justify-center gap-4 text-gray-500">
          <div className="flex items-center gap-2"><BadgeCheck className="w-5 h-5" /> Authorized Cisco Partner</div>
          <div className="flex items-center gap-2"><Lock className="w-5 h-5" /> Secure Payment</div>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className="flex justify-center gap-6 text-lg font-medium text-gray-700 border-b border-gray-200 mb-10">
        {['Bundle', 'Exam Voucher', 'Practice Test', 'E-Learning Course'].map(tab => (
          <button
            key={tab}
            className={`pb-2 ${activeTab === tab ? 'border-b-4 border-blue-600 text-black' : 'text-gray-500'}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
          </button>
        ))}
      </div>

        {renderTabContent()}

      {/* Why EtrainIndia */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-6">Why Get Certified with EtrainIndia?</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-gray-700">
          <div className="flex items-center gap-2"><BadgeCheck className="w-5 h-5" /> Certified & Job-Ready</div>
          <div className="flex items-center gap-2"><GraduationCap className="w-5 h-5" /> Official Curriculum</div>
          <div className="flex items-center gap-2"><CheckCircle className="w-5 h-5" /> Exam Success</div>
          <div className="flex items-center gap-2"><VideoIcon className="w-5 h-5" /> Digital Badge</div>
        </div>
      </section>

      {/* Video Testimonial */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-4">Learner Success Story</h2>
        <div className="flex flex-col md:flex-row gap-6 items-center">
          <div className="w-full md:w-1/2">
            <div className="relative aspect-video bg-black rounded-md overflow-hidden">
              <iframe
                className="w-full h-full"
                src="https://www.youtube.com/embed/sample"
                title="Testimonial"
                allowFullScreen
              ></iframe>
            </div>
          </div>
          <div className="w-full md:w-1/2">
            <p className="italic text-gray-700">"The CCNA program at EtrainIndia gave me the confidence and skills to switch careers."</p>
            <p className="font-semibold text-gray-800 mt-2">Jane D. <span className="text-sm text-gray-600">Network Engineer</span></p>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="mb-12">
        <div className="space-y-4">
          <div>
            <div className="flex items-center gap-2 text-yellow-500"><FaStar /><FaStar /><FaStar /><FaStar /><FaStar /></div>
            <p className="text-gray-700">I passed my CCNA on the first try, thanks to the thorough course and practice exams.</p>
            <p className="text-sm text-gray-500 mt-1">– Raj M.</p>
          </div>
          <div>
            <div className="flex items-center gap-2 text-yellow-500"><FaStar /><FaStar /><FaStar /><FaStar /><FaStar /></div>
            <p className="text-gray-700">The videos were clear and the team support was excellent throughout.</p>
            <p className="text-sm text-gray-500 mt-1">– Ananya G.</p>
          </div>
        </div>
      </section>

      {/* Course Details */}
      <section className="mb-12">
        <h2 className="text-2xl font-bold mb-4">About the Course</h2>
        <p className="text-gray-600 mb-4">This self-paced online course covers all CCNA exam domains with engaging video lectures, hands-on labs, and quizzes. Suitable for beginners in networking.</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold mb-2">What You'll Learn</h3>
            <ul className="list-disc pl-6 text-gray-700 space-y-1">
              <li>Networking Fundamentals (OSI model, IPv4)</li>
              <li>Routing and Switching Essentials</li>
              <li>Network Security Basics</li>
              <li>Wireless and WAN Concepts</li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Course Details</h3>
            <ul className="list-disc pl-6 text-gray-700 space-y-1">
              <li>40 hours of video</li>
              <li>10 lessons, 100 practice questions</li>
              <li>Certificate of completion</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
      <Footer/>
    </div>
  );
};

export default CoursePage;