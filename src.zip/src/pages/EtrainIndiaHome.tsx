import React from "react";

/* ---------------------- Types & data ---------------------- */

type Stat = {
  label: string;
  value: string;
};

type Testimonial = {
  name: string;
  role: string;
  text: string;
};

type Course = {
  vendor: string;
  title: string;
  desc: string;
  level: string;
  price: string;
  duration: string;
};

const partners = [
  "HCLTech",
  "IBM",
  "Certiport",
  "IC3",
  "Intuit",
  "Pearson",
];

const popularCourses: Course[] = [
  {
    vendor: "IBM",
    title: "IBM Certifications",
    desc: "Cloud • AI • Cybersecurity",
    level: "Intermediate",
    price: "From ₹4,999",
    duration: "3–6 months",
  },
  {
    vendor: "Meta",
    title: "Certified Digital Marketing Associate",
    desc: "Social • Ads • Analytics",
    level: "Beginner",
    price: "From ₹3,999",
    duration: "4–8 weeks",
  },
  {
    vendor: "Pearson",
    title: "Information Technology Specialist",
    desc: "IT Fundamentals • Networking • Python",
    level: "Beginner",
    price: "From ₹2,999",
    duration: "4–12 weeks",
  },
];

const stats: Stat[] = [
  { value: "87%", label: "Learners report career benefits" },
  { value: "15K+", label: "Professionals certified" },
  { value: "120+", label: "Global certifications & exams" },
];

const testimonials: Testimonial[] = [
  {
    name: "Abhishika K.N",
    role: "Engineer",
    text: "Graduation from the UX Career Acceleration Program by EtrainIndia was an enriching journey exploring UX concepts, design tools and product design.",
  },
  {
    name: "Rahul Sharma",
    role: "UI/UX Designer – TechCorp",
    text: "The mentorship, hands-on projects and career support from EtrainIndia helped me transition into a product design role with confidence.",
  },
  {
    name: "Ritesh Kumar Verma",
    role: "Software Engineer – TechCorp",
    text: "EtrainIndia's structured programs and global certifications helped me sharpen my skills and open doors to opportunities I never imagined.",
  },
];

/* ---------------------- SVG components ---------------------- */

const LogoWordmark: React.FC = () => (
  <svg
    className="h-9"
    viewBox="0 0 220 40"
    xmlns="http://www.w3.org/2000/svg"
    aria-label="EtrainIndia logo"
  >
    <defs>
      <style>
        {`
        .brand-main { fill: #14324B; font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
        .brand-green { fill: #00994C; }
        .brand-orange { fill: #F68A1E; }
        .tagline { fill: #5B6B7C; font-size: 9px; }
      `}
      </style>
    </defs>
    {/* simple circular globe background */}
    <circle cx="18" cy="18" r="16" fill="#14324B" opacity="0.08" />
    <circle cx="18" cy="18" r="12" fill="#00994C" opacity="0.18" />
    {/* wordmark */}
    <text x="40" y="20" fontSize="18" className="brand-main" fontWeight="600">
      etrain
    </text>
    <text x="94" y="20" fontSize="18" className="brand-orange" fontWeight="600">
      In
    </text>
    <text x="118" y="20" fontSize="18" className="brand-green" fontWeight="600">
      dia
    </text>
    {/* tagline */}
    <text x="40" y="32" className="tagline">
      Empowering Education
    </text>
  </svg>
);

export const HeroIllustration: React.FC = () => (
  <svg
    className="w-full max-w-md"
    viewBox="0 0 360 260"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <defs>
      <style>
        {`
        .skin { fill: #F6B38D; }
        .hair { fill: #4A2F2F; }
        .shirt { fill: #F68A1E; }
        .shirt-stripe { stroke: #FBC999; stroke-width: 2; }
        .desk { fill: #F3F4F6; }
        .laptop-body { fill: #CBD5F5; }
        .laptop-screen { fill: #E5EDFF; }
      `}
      </style>
    </defs>

    {/* soft ground */}
    <ellipse cx="180" cy="220" rx="150" ry="30" fill="#E5F0FF" />

    {/* desk */}
    <rect x="40" y="200" width="280" height="18" className="desk" rx="8" />

    {/* laptop */}
    <rect x="170" y="135" width="110" height="70" rx="6" className="laptop-body" />
    <rect x="176" y="140" width="98" height="52" rx="4" className="laptop-screen" />
    <circle cx="224" cy="145" r="3" fill="#A5B4FC" />
    <rect x="160" y="200" width="130" height="8" rx="4" fill="#94A3B8" />

    {/* body */}
    <path
      className="shirt"
      d="M118 150C130 135 152 134 166 145C180 156 186 176 186 196H104C104 176 106 165 118 150Z"
    />
    <path className="shirt-stripe" d="M112 157C132 152 151 152 172 157" />
    <path className="shirt-stripe" d="M110 166C132 162 151 162 174 166" />
    <path className="shirt-stripe" d="M110 175C132 171 151 171 174 175" />

    {/* arms */}
    <path
      className="skin"
      d="M170 176C180 176 186 182 190 192L183 196C180 190 176 187 170 186Z"
    />
    <path
      className="skin"
      d="M112 176C102 179 96 188 94 198L102 201C104 195 108 189 114 186Z"
    />

    {/* head */}
    <circle cx="140" cy="118" r="30" className="skin" />
    <path
      className="hair"
      d="M112 112C114 92 126 80 142 80C158 80 170 92 172 112C173 126 170 143 162 150C158 146 152 143 140 143C128 143 120 146 116 150C110 144 110 128 112 112Z"
    />
    <circle cx="132" cy="116" r="2.4" fill="#1F2933" />
    <circle cx="148" cy="116" r="2.4" fill="#1F2933" />
    <path
      d="M132 127C136 132 144 132 148 127"
      fill="none"
      stroke="#C05621"
      strokeWidth="1.6"
      strokeLinecap="round"
    />

    {/* notebook */}
    <rect
      x="84"
      y="198"
      width="60"
      height="10"
      rx="2"
      fill="#FFFFFF"
      stroke="#CBD5E1"
      strokeWidth="1.5"
    />
    <line x1="84" y1="201" x2="144" y2="201" stroke="#E2E8F0" strokeWidth="1" />

    {/* pen */}
    <rect x="146" y="188" width="4" height="22" rx="2" fill="#0EA5E9" />
  </svg>
);

/* ---------------------- Small UI helpers ---------------------- */

const ArrowRightIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg
    className={className}
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M5 10H15"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
    />
    <path
      d="M11 6L15 10L11 14"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/* ---------------------- Main page ---------------------- */

const EtrainIndiaHome: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* NAVBAR */}
      <header className="sticky top-0 z-40 border-b border-slate-100 bg-white/70 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 lg:px-0">
          <div className="flex items-center gap-3">
            <LogoWordmark />
          </div>

          <nav className="hidden items-center gap-6 text-sm font-medium text-slate-600 md:flex">
            <button className="hover:text-slate-900">Courses</button>
            <button className="hover:text-slate-900">Certifications</button>
            <button className="hover:text-slate-900">For Colleges</button>
            <button className="hover:text-slate-900">For Corporates</button>
            <button className="hover:text-slate-900">Partner with Us</button>
          </nav>

          <div className="flex items-center gap-3">
            <input
              className="hidden rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-1 focus:ring-emerald-500 md:block"
              placeholder="Search courses..."
            />
            <button className="rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:border-slate-300">
              Login / Signup
            </button>
          </div>
        </div>
      </header>

      <main>
        {/* HERO */}
        <section className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-amber-50 via-emerald-50 to-sky-50" />
          <div className="absolute -right-40 -top-40 h-80 w-80 rounded-full bg-orange-200/40 blur-3xl" />
          <div className="absolute -left-40 bottom-0 h-80 w-80 rounded-full bg-emerald-200/50 blur-3xl" />

          <div className="relative mx-auto flex max-w-6xl flex-col items-center gap-12 px-4 py-14 lg:flex-row lg:py-20">
            {/* Left content */}
            <div className="flex-1">
              <div className="inline-flex items-center gap-2 rounded-full border border-emerald-100 bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700">
                World-class certifications &amp; training
              </div>

              <h1 className="mt-4 text-4xl font-semibold tracking-tight text-slate-900 sm:text-5xl lg:text-6xl">
                <span className="block text-emerald-600">Future-Ready</span>
                <span className="block">Tech Skills.</span>
              </h1>

              <p className="mt-4 max-w-xl text-sm leading-relaxed text-slate-600 sm:text-base">
                Learn from the world&apos;s best edtech platform with hands-on
                projects, expert-led mentorship, and globally recognized
                certifications with EtrainIndia.
              </p>

              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button className="group inline-flex items-center gap-2 rounded-full bg-emerald-600 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition hover:bg-emerald-700 focus:outline-none">
                  <span>Start Learning Now</span>
                  <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </button>
                <button className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-5 py-2.5 text-sm font-medium text-slate-700 shadow-sm hover:border-slate-300">
                  Explore all courses
                </button>
              </div>

              <div className="mt-5 flex items-center gap-4">
                <div className="flex -space-x-2">
                  <div className="h-8 w-8 rounded-full bg-emerald-500 outline outline-2 outline-slate-50" />
                  <div className="h-8 w-8 rounded-full bg-sky-500 outline outline-2 outline-slate-50" />
                  <div className="h-8 w-8 rounded-full bg-indigo-500 outline outline-2 outline-slate-50" />
                </div>
                <p className="text-xs text-slate-600 sm:text-sm">
                  <span className="font-semibold text-slate-900">
                    15,000+ learners
                  </span>{" "}
                  certified across campuses &amp; corporates.
                </p>
              </div>
            </div>

            {/* Right content */}
            <div className="flex flex-1 justify-center">
              <div className="relative">
                <div className="absolute -inset-6 rounded-3xl bg-gradient-to-tr from-emerald-200 via-sky-200 to-transparent opacity-70 blur-2xl" />
                <div className="relative rounded-3xl border border-slate-100 bg-white p-6 shadow-xl">
                  <img src="https://etrain.blr1.cdn.digitaloceanspaces.com/imageheader.jpg" alt="" />
                  <div className="mt-4 flex items-center justify-between gap-4 text-xs text-slate-600">
                    <div>
                      <p className="text-[10px] uppercase tracking-wide text-slate-500">
                        Current program
                      </p>
                      <p className="text-sm font-semibold text-slate-900">
                        IBM Certified Data Analyst
                      </p>
                    </div>
                    <div className="rounded-full bg-emerald-50 px-3 py-1 text-[11px] font-medium text-emerald-700">
                      Global Certificate
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* PARTNER LOGOS */}
        <section className="border-y border-slate-100 bg-white">
          <div className="mx-auto max-w-6xl px-4 py-10">
            <p className="mb-6 text-center text-xs font-semibold uppercase tracking-[0.25em] text-slate-500">
              Get certified by world&apos;s leading IT companies
            </p>
            <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10">
              {partners.map((name) => (
                <div
                  key={name}
                  className="px-4 py-2 text-sm font-semibold text-slate-400 transition hover:text-slate-700"
                >
                  {name}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* POPULAR COURSES */}
        <section className="bg-slate-50">
          <div className="mx-auto max-w-6xl px-4 py-16">
            <div className="mb-10 text-center">
              <h2 className="text-3xl font-semibold text-slate-900 sm:text-4xl">
                Popular Courses &amp; Certifications
              </h2>
              <p className="mt-3 text-sm text-slate-600 sm:text-base">
                Master in-demand skills with globally recognized credentials in
                technology, business, and digital careers.
              </p>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              {popularCourses.map((course) => (
                <article
                  key={course.title}
                  className="group relative rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition hover:shadow-lg"
                >
                  <div className="inline-flex items-center gap-2 rounded-full bg-slate-50 px-3 py-1 text-xs font-medium text-slate-600">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-emerald-100 text-[11px] font-semibold text-emerald-700">
                      {course.vendor[0]}
                    </div>
                    <span>{course.vendor}</span>
                  </div>

                  <h3 className="mt-4 text-lg font-semibold text-slate-900">
                    {course.title}
                  </h3>
                  <p className="mt-1 text-sm text-slate-600">{course.desc}</p>

                  <div className="mt-4 flex flex-wrap gap-2">
                    <span className="inline-flex items-center rounded-full bg-emerald-50 px-2.5 py-1 text-[11px] font-medium text-emerald-700">
                      {course.level}
                    </span>
                    <span className="inline-flex items-center rounded-full bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600">
                      Exam Included
                    </span>
                    <span className="inline-flex items-center rounded-full bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600">
                      Placement Support
                    </span>
                  </div>

                  <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
                    <span>{course.price}</span>
                    <span>{course.duration}</span>
                  </div>

                  <button className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-emerald-700 group-hover:text-emerald-800">
                    View program
                    <ArrowRightIcon className="h-4 w-4" />
                  </button>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* LEARNER OUTCOMES */}
        <section className="bg-white">
          <div className="mx-auto grid max-w-6xl items-center gap-12 px-4 py-16 lg:grid-cols-2 lg:py-20">
            {/* visual */}
            <div className="flex justify-center">
              <div className="relative h-72 w-72 sm:h-80 sm:w-80">
                <div className="absolute inset-0 flex items-center justify-center rounded-full bg-slate-900">
                  <span className="text-[180px] font-black text-slate-800 sm:text-[220px]">
                    e
                  </span>
                </div>
                <div className="absolute inset-6 rounded-full bg-gradient-to-tr from-emerald-400 via-emerald-500 to-sky-400 p-1 sm:inset-8">
                  <div className="flex h-full w-full flex-col items-center justify-center rounded-full bg-white px-6 text-center">
                    <div className="mb-3 h-16 w-16 rounded-full bg-emerald-100" />
                    <p className="mb-1 text-sm font-medium text-slate-900">
                      Learner-First Outcomes
                    </p>
                    <p className="text-xs text-slate-500">
                      Designed to move you from classroom learning to
                      real-world roles.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* content */}
            <div className="space-y-6">
              <h2 className="text-3xl font-semibold text-slate-900 sm:text-4xl">
                Learner outcomes on EtrainIndia
              </h2>
              <p className="text-sm text-slate-600 sm:text-base">
                87% of learners across campuses and corporates report
                career-defining benefits after certifying with EtrainIndia —
                from skill growth to promotions, better jobs, and professional
                excellence.
              </p>

              <div className="grid gap-4 sm:grid-cols-3">
                {stats.map((s) => (
                  <div
                    key={s.label}
                    className="rounded-2xl border border-slate-100 bg-slate-50 px-4 py-5"
                  >
                    <p className="text-2xl font-semibold text-emerald-600">
                      {s.value}
                    </p>
                    <p className="mt-1 text-xs text-slate-600">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* TESTIMONIALS */}
        <section className="border-y border-slate-100 bg-slate-50">
          <div className="mx-auto max-w-6xl px-4 py-16">
            <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.25em] text-emerald-600">
                  Hear it from them
                </p>
                <h2 className="mt-2 text-3xl font-semibold text-slate-900">
                  Certified People ❤️ EtrainIndia
                </h2>
              </div>
              <button className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 hover:text-emerald-700">
                View more success stories on LinkedIn
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-slate-900 text-[10px] font-semibold text-white">
                  in
                </span>
              </button>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              {testimonials.map((t) => (
                <article
                  key={t.name}
                  className="relative rounded-2xl border border-slate-100 bg-white p-6 shadow-sm"
                >
                  <div className="absolute right-4 top-4 inline-flex items-center gap-1 rounded-full bg-slate-900 px-2 py-1 text-[10px] text-white">
                    <span className="flex h-4 w-4 items-center justify-center rounded-full bg-white text-[9px] font-semibold text-slate-900">
                      in
                    </span>
                    <span>Verified</span>
                  </div>
                  <p className="mb-4 line-clamp-5 text-sm text-slate-600">
                    {t.text}
                  </p>
                  <div className="mt-3 flex items-center gap-3 border-t border-slate-100 pt-3">
                    <div className="h-9 w-9 rounded-full bg-emerald-100" />
                    <div>
                      <p className="text-sm font-semibold text-slate-900">
                        {t.name}
                      </p>
                      <p className="text-xs text-slate-500">{t.role}</p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* BUSINESS CTA */}
        <section className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white">
          <div className="mx-auto flex max-w-6xl flex-col items-center gap-8 px-4 py-12 lg:flex-row lg:py-16">
            <div className="flex-1 space-y-4">
              <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-medium">
                <span className="h-4 w-4 rounded-full bg-emerald-400" />
                <span>For Colleges &amp; Corporates</span>
              </div>
              <h2 className="text-2xl font-semibold sm:text-3xl">
                Upskill your students &amp; teams with EtrainIndia.
              </h2>
              <p className="max-w-xl text-sm text-slate-200 sm:text-base">
                Deploy job-ready programs with global certifications, hands-on
                labs, and dedicated support for your institution or
                organization.
              </p>
              <div className="flex flex-wrap gap-3 text-xs text-slate-200 sm:text-sm">
                <span className="rounded-full bg-white/10 px-3 py-1">
                  Placement-aligned curriculum
                </span>
                <span className="rounded-full bg-white/10 px-3 py-1">
                  Global vendor credentials
                </span>
                <span className="rounded-full bg-white/10 px-3 py-1">
                  Dedicated success manager
                </span>
              </div>
            </div>

            <div className="flex flex-1 justify-center lg:justify-end">
              <button className="inline-flex items-center gap-2 rounded-full bg-emerald-500 px-6 py-3 text-sm font-semibold text-slate-900 shadow-lg transition hover:bg-emerald-400">
                Book a consultation
                <ArrowRightIcon className="h-4 w-4" />
              </button>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-white">
        <div className="mx-auto max-w-6xl border-t border-slate-100 px-4 py-10">
          <div className="grid gap-8 text-sm md:grid-cols-4">
            <div>
              <p className="mb-2 font-semibold text-slate-900">About Etrain</p>
              <ul className="space-y-1 text-slate-600">
                <li>About Us</li>
                <li>Our Story</li>
                <li>Careers</li>
              </ul>
            </div>
            <div>
              <p className="mb-2 font-semibold text-slate-900">
                Popular Courses
              </p>
              <ul className="space-y-1 text-slate-600">
                <li>IBM Certifications</li>
                <li>Microsoft Office Specialist</li>
                <li>Meta Digital Marketing</li>
              </ul>
            </div>
            <div>
              <p className="mb-2 font-semibold text-slate-900">Resources</p>
              <ul className="space-y-1 text-slate-600">
                <li>Blog</li>
                <li>Support</li>
                <li>FAQs</li>
              </ul>
            </div>
            <div>
              <p className="mb-2 font-semibold text-slate-900">Contact</p>
              <ul className="space-y-1 text-slate-600">
                <li>Email: support@etrainindia.com</li>
                <li>India</li>
              </ul>
            </div>
          </div>

          <div className="mt-8 flex flex-col items-center justify-between gap-4 text-xs text-slate-500 sm:flex-row">
            <p>
              © {new Date().getFullYear()} EtrainIndia. All rights reserved.
            </p>
            <div className="flex items-center gap-4">
              <span>Terms</span>
              <span>Privacy</span>
              <span>Cookies</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default EtrainIndiaHome;
